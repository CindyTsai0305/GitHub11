#!/bin/bash

tar -xvf pkm

cd pkm

gem install --local zeitwerk-2.7.1.gem
gem install --local activesupport-6.1.7.10.gem
gem install --local nap-1.1.0.gem
gem install --local rexml-3.4.1.gem
gem install --local cocoapods-downloader-1.6.3.gem
gem install --local cocoapods-core-1.12.1.gem
gem install --local xcodeproj-1.27.0.gem
gem install --local nanaimo-0.4.0.gem

gem install --local cocoapods-1.12.1.gem

export PATH="$(gem environment gemdir)/bin:$PATH"
pod --version